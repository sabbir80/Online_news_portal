-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2020 at 05:17 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `name`, `email`, `password`) VALUES
(1, 'Sabbir', 'sabbir1234@gmail.com', '123456'),
(2, 'rana', 'rana@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `approved`
--

CREATE TABLE `approved` (
  `id` int(100) NOT NULL,
  `post` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(100) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `des`) VALUES
(23, 'World', 'World'),
(24, 'Technology', 'Techonology\r\n'),
(25, 'Sports', 'Sports'),
(26, 'Design', 'Design'),
(27, 'Culture', 'Culture'),
(28, 'Health', 'Health'),
(29, 'Business', 'Business'),
(30, 'Politics', 'Politics'),
(31, 'Travel', 'Travel'),
(32, 'Style', 'Style');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(100) NOT NULL,
  `postid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `category` varchar(100) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `admin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `date`, `category`, `thumbnail`, `admin`) VALUES
(46, 'India extends lockdown till May 17', 'Indian Prime Minister Narendra Modi addresses the nation on Tuesday for the fifth time since the nationwide lockdown due to deadly coronavirus has been imposed. His address comes after a six-hour-long meeting with the state Chief Ministers regarding the fate of the lockdown 3.0 which is scheduled to end on May 17. The first lockdown was imposed for 21 days on March 25 after which it extended till May 3 for another 19 days. It has been extended for another two weeks till May 17. Both the lockdowns were announced by the Prime Minister himself through an address to the nation while for the decision of the third extension, he was unavailable. Many states are in favour of resuming economic activity outside containment zones. The video conference with the chief ministers focused on ways to strengthen the COVID-19 containment strategy and stepping up of economic activities in a calibrated manner post the 54-day shutdown.', '2020-05-13', 'World', 'World.jpg', 'Dallas'),
(47, 'Facebook opens fact-checking program to check misinformation', 'Facebook today announced the launch of its third-party fact-checking program in Bangladesh as part of its ongoing integrity efforts to reduce the spread of misinformation and improve the quality of the news people find online. Facebook will partner with BOOM, which has been certified by the Poynter Institute’s non-partisan international fact checking network, said a press release here. Starting today, BOOM will review and rate the accuracy of stories on Facebook, including photos and videos in Bangladesh. When third-party fact-checkers rate a story as false, it will appear lower in news feed, significantly reducing its distribution. “We know that people want to see accurate information on Facebook and we are excited to announce the continued growth of our third-party fact-checking program through our partnership with BOOM for Bangladesh. We believe that with this fact-checking program, we can help build a more informed community and look forward to exploring more opportunities to expand this program locally.” said Anjali Kapoor, Facebook’s News Partnership Director of APAC. This program is in line with Facebook’s three-part framework to improve the quality and authenticity of stories in the News Feed. When third-party fact-checkers write articles about a piece of content, Facebook will show these in related articles immediately below the story in news feed. Page admins and people on Facebook will also receive notifications if they try to share a post or have shared one that’s been determined to be false, empowering people to decide for themselves what to read, trust, and share.', '2020-04-19', 'Technology', 'Technology.jpg', 'Rahim'),
(48, 'IPL 2020 postponed until further notice', 'The 13th edition of the Indian Premier League (IPL) has been postponed indefinitely because of the coronavirus pandemic, BCCI Honorary Secretary Jay Shah said in a press release on Thursday. \"Due to the evolving global health concerns regarding COVID-19 and lockdown measures implemented by the Government of India to contain the spread of the pandemic, the IPL Governing Council of the BCCI has decided that the IPL 2020 Season will be suspended till further notice,\" the release read. The IPL had already been pushed back from its original start date of March 29 to April 15 and a further delay was inevitable after the government extended a three-week lockdown until at least May 3. \"The health and safety of the nation and everyone involved in our great sport remains our top priority and as such, the BCCI along with the Franchise Owners, Broadcaster, Sponsors and all the Stakeholders acknowledge that the IPL 2020 season will only commence when it is safe and appropriate to do so,\" the release read further. \"BCCI will continue to monitor and review the situation regarding a potential start date in close partnership with all of its stakeholders and will continue to take guidance from the Government of India, State Governments and other State Regulatory bodies,\" the release concluded. Former India batsman VVS Laxman said that the IPL should be played before the Twenty20 World Cup, which is scheduled to be held in Australia in October and November. Former England cricketer Kevin Pietersen suggested that the tournament should be shortened from its normal eight-week duration and played behind closed doors.', '2020-04-16', 'Sports', 'Sports.jpg', 'Gias'),
(49, '‘TRESemmé Bangladesh Fashion Week 2019’ comes to a close', 'American multinational brand TRESemmé has organised an event in Bangladesh titled “TRESemmé Bangladesh Fashion Week 2019,” which it says is the biggest fashion event in the country. The three-day long event was held from Feb 23 to Feb 25 at the International Convention City Bashundhara in Dhaka. It showcased the designs of 19 Bangladeshis and 11 foreigners. It also featured the works of some of the top hairstylists of Bangladesh. The Bangladeshi designers who displayed their works on the first day of the event were Humaira Khan, Riffat Reza Raka, Sadiya Mishu, Sarah Karim, Musarrat Rahman, Ezmat Naz Rima and Lipi Khandker. The international designers on the first day were Paromita Banerjee from India, Aishath Shamla from the Maldives and Anu Shrestha from Nepal. Afroza Parveen was the hairstylist for day one. The second day saw seven Bangladeshis displaying their works: Farah Anjum Bari, Shah Rukh Amin, Afsana Ferdousi, Faiza Ahmed, Rupo Shams, Tasfia Ahmed and Shaibal Saha. Sukajit Daengchai from Thailand, Kencho Wangmo from Bhutan and Swati Kalsi from India were the international designers on day two. Kaniz Almas took care of the hairstyles on day two of the event. Fashion Design Council of Bangladesh (FDCB) was the creative partner for the event and its hospitality partner was Le Meridien Dhaka. The TRESemmé brand of hair care products was launched in 1947 by the Godefroy Manufacturing Company in St. Louis, Missouri, United States. The brand name is a phonetic respelling of \"well-loved\" (French: très-aimé.)', '2019-02-26', 'Design', 'Design.jpg', 'Mimi');

-- --------------------------------------------------------

--
-- Table structure for table `published`
--

CREATE TABLE `published` (
  `id` int(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `category` varchar(100) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `admin` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `published`
--

INSERT INTO `published` (`id`, `title`, `description`, `date`, `category`, `thumbnail`, `admin`) VALUES
(20, 'India extends lockdown till May 17', 'Indian Prime Minister Narendra Modi addresses the nation on Tuesday for the fifth time since the nationwide lockdown due to deadly coronavirus has been imposed. His address comes after a six-hour-long meeting with the state Chief Ministers regarding the fate of the lockdown 3.0 which is scheduled to end on May 17. The first lockdown was imposed for 21 days on March 25 after which it extended till May 3 for another 19 days. It has been extended for another two weeks till May 17. Both the lockdowns were announced by the Prime Minister himself through an address to the nation while for the decision of the third extension, he was unavailable. Many states are in favour of resuming economic activity outside containment zones. The video conference with the chief ministers focused on ways to strengthen the COVID-19 containment strategy and stepping up of economic activities in a calibrated manner post the 54-day shutdown.', '2020-05-13', 'World', 'World.jpg', 'Dallas'),
(21, 'Facebook opens fact-checking program to check misinformation', 'Facebook today announced the launch of its third-party fact-checking program in Bangladesh as part of its ongoing integrity efforts to reduce the spread of misinformation and improve the quality of the news people find online. Facebook will partner with BOOM, which has been certified by the Poynter Institute’s non-partisan international fact checking network, said a press release here. Starting today, BOOM will review and rate the accuracy of stories on Facebook, including photos and videos in Bangladesh. When third-party fact-checkers rate a story as false, it will appear lower in news feed, significantly reducing its distribution. “We know that people want to see accurate information on Facebook and we are excited to announce the continued growth of our third-party fact-checking program through our partnership with BOOM for Bangladesh. We believe that with this fact-checking program, we can help build a more informed community and look forward to exploring more opportunities to expand this program locally.” said Anjali Kapoor, Facebook’s News Partnership Director of APAC. This program is in line with Facebook’s three-part framework to improve the quality and authenticity of stories in the News Feed. When third-party fact-checkers write articles about a piece of content, Facebook will show these in related articles immediately below the story in news feed. Page admins and people on Facebook will also receive notifications if they try to share a post or have shared one that’s been determined to be false, empowering people to decide for themselves what to read, trust, and share.', '2020-04-19', 'Technology', 'Technology.jpg', 'Rahim'),
(22, 'IPL 2020 postponed until further notice', 'The 13th edition of the Indian Premier League (IPL) has been postponed indefinitely because of the coronavirus pandemic, BCCI Honorary Secretary Jay Shah said in a press release on Thursday. \"Due to the evolving global health concerns regarding COVID-19 and lockdown measures implemented by the Government of India to contain the spread of the pandemic, the IPL Governing Council of the BCCI has decided that the IPL 2020 Season will be suspended till further notice,\" the release read. The IPL had already been pushed back from its original start date of March 29 to April 15 and a further delay was inevitable after the government extended a three-week lockdown until at least May 3. \"The health and safety of the nation and everyone involved in our great sport remains our top priority and as such, the BCCI along with the Franchise Owners, Broadcaster, Sponsors and all the Stakeholders acknowledge that the IPL 2020 season will only commence when it is safe and appropriate to do so,\" the release read further. \"BCCI will continue to monitor and review the situation regarding a potential start date in close partnership with all of its stakeholders and will continue to take guidance from the Government of India, State Governments and other State Regulatory bodies,\" the release concluded. Former India batsman VVS Laxman said that the IPL should be played before the Twenty20 World Cup, which is scheduled to be held in Australia in October and November. Former England cricketer Kevin Pietersen suggested that the tournament should be shortened from its normal eight-week duration and played behind closed doors.', '2020-04-16', 'Sports', 'Sports.jpg', 'Gias'),
(23, '‘TRESemmé Bangladesh Fashion Week 2019’ comes to a close', 'American multinational brand TRESemmé has organised an event in Bangladesh titled “TRESemmé Bangladesh Fashion Week 2019,” which it says is the biggest fashion event in the country. The three-day long event was held from Feb 23 to Feb 25 at the International Convention City Bashundhara in Dhaka. It showcased the designs of 19 Bangladeshis and 11 foreigners. It also featured the works of some of the top hairstylists of Bangladesh. The Bangladeshi designers who displayed their works on the first day of the event were Humaira Khan, Riffat Reza Raka, Sadiya Mishu, Sarah Karim, Musarrat Rahman, Ezmat Naz Rima and Lipi Khandker. The international designers on the first day were Paromita Banerjee from India, Aishath Shamla from the Maldives and Anu Shrestha from Nepal. Afroza Parveen was the hairstylist for day one. The second day saw seven Bangladeshis displaying their works: Farah Anjum Bari, Shah Rukh Amin, Afsana Ferdousi, Faiza Ahmed, Rupo Shams, Tasfia Ahmed and Shaibal Saha. Sukajit Daengchai from Thailand, Kencho Wangmo from Bhutan and Swati Kalsi from India were the international designers on day two. Kaniz Almas took care of the hairstyles on day two of the event. Fashion Design Council of Bangladesh (FDCB) was the creative partner for the event and its hospitality partner was Le Meridien Dhaka. The TRESemmé brand of hair care products was launched in 1947 by the Godefroy Manufacturing Company in St. Louis, Missouri, United States. The brand name is a phonetic respelling of \"well-loved\" (French: très-aimé.)', '2019-02-26', 'Design', 'Design.jpg', 'Mimi');

-- --------------------------------------------------------

--
-- Table structure for table `reporter`
--

CREATE TABLE `reporter` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reporter`
--

INSERT INTO `reporter` (`id`, `name`, `email`, `category`, `password`) VALUES
(3, 'Dallas', 'dallas@gmail.com', 'World', '1234'),
(4, 'Rahim', 'rahim@gmail.com', 'Technology', '1234'),
(5, 'Gias', 'gias@gmail.com', 'Sports', '1234'),
(6, 'Mimi', 'mimi@gmail.com', 'Design', '1234'),
(7, 'Nahid', 'nahid@gmail.com', 'Culture', '1234'),
(8, 'Siam', 'siam@gmail.com', 'Health', '1234'),
(9, 'Lamiya', 'lamiya@gmail.com', 'Business', '1234'),
(10, 'Suborno', 'suborno@gmail.com', 'Politics', '1234'),
(11, 'Afra', 'afra@gmail.com', 'Style', '1234'),
(12, 'Sabbir', 'sabbir1234@gmail.com', 'Travel', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`) VALUES
(4, 'Sabbir', 'sabbir1234@gmail.com'),
(5, 'Tawhid', 'tawhid@gmail.com'),
(6, 'Mimi', 'mimi@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `approved`
--
ALTER TABLE `approved`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `published`
--
ALTER TABLE `published`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reporter`
--
ALTER TABLE `reporter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `approved`
--
ALTER TABLE `approved`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `published`
--
ALTER TABLE `published`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `reporter`
--
ALTER TABLE `reporter`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
